import { FunctionComponent, useMemo, type CSSProperties } from "react";
import "./DropdownRegular.css";

type DropdownRegularType = {
  category?: string;
  general01Icons06Messages?: string;
  name1?: string;
  general01Icons02Common?: string;
  name2?: string;

  /** Style props */
  propPadding?: CSSProperties["padding"];
  propDisplay?: CSSProperties["display"];
};

const DropdownRegular: FunctionComponent<DropdownRegularType> = ({
  category,
  general01Icons06Messages,
  name1,
  general01Icons02Common,
  name2,
  propPadding,
  propDisplay,
}) => {
  const focusFieldTypeStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const categoryStyle: CSSProperties = useMemo(() => {
    return {
      display: propDisplay,
    };
  }, [propDisplay]);

  return (
    <div className="dropdown-regular">
      <div className="focus-field-type" style={focusFieldTypeStyle}>
        <div className="category" style={categoryStyle}>
          {category}
        </div>
      </div>
      <div className="frame-parent1">
        <button className="frame">
          <div className="type13" />
          <img
            className="general-01-icons-06-messag"
            alt=""
            src={general01Icons06Messages}
          />
          <div className="name24">{name1}</div>
        </button>
        <button className="column-one-column-two">
          <div className="type14" />
          <img
            className="general-01-icons-02-common4"
            alt=""
            src={general01Icons02Common}
          />
          <div className="name25">{name2}</div>
        </button>
      </div>
    </div>
  );
};

export default DropdownRegular;
