import { FunctionComponent } from "react";
import TextValueLabel from "./TextValueLabel";
import DropdownRegular from "./DropdownRegular";
import "./Navigation1.css";

const Navigation1: FunctionComponent = () => {
  return (
    <div className="navigation">
      <div className="bg32" />
      <TextValueLabel />
      <DropdownRegular
        category="Other Information"
        general01Icons06Messages="/00-general--01-icons--06-messages--03-question@2x.png"
        name1="Knowledge Base"
        general01Icons02Common="/00-general--01-icons--02-common--29-ribbon@2x.png"
        name2="Product Updates"
      />
      <DropdownRegular
        category="Settings"
        general01Icons06Messages="/00-general--01-icons--02-common--02-user@2x.png"
        name1="Personal Settings"
        general01Icons02Common="/00-general--01-icons--02-common--01-settings-2@2x.png"
        name2="Global Settings"
        propPadding="0rem var(--padding-base)"
        propDisplay="inline-block"
      />
    </div>
  );
};

export default Navigation1;
