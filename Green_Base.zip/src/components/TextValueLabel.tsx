import { FunctionComponent, useMemo, type CSSProperties } from "react";
import "./TextValueLabel.css";

type TextValueLabelType = {
  /** Style props */
  propDisplay?: CSSProperties["display"];
  propDisplay1?: CSSProperties["display"];
  propDisplay2?: CSSProperties["display"];
  propDisplay3?: CSSProperties["display"];
  propDisplay4?: CSSProperties["display"];
  propDisplay5?: CSSProperties["display"];
};

const TextValueLabel: FunctionComponent<TextValueLabelType> = ({
  propDisplay,
  propDisplay1,
  propDisplay2,
  propDisplay3,
  propDisplay4,
  propDisplay5,
}) => {
  const nameStyle: CSSProperties = useMemo(() => {
    return {
      display: propDisplay,
    };
  }, [propDisplay]);

  const name1Style: CSSProperties = useMemo(() => {
    return {
      display: propDisplay1,
    };
  }, [propDisplay1]);

  const name2Style: CSSProperties = useMemo(() => {
    return {
      display: propDisplay2,
    };
  }, [propDisplay2]);

  const name3Style: CSSProperties = useMemo(() => {
    return {
      display: propDisplay3,
    };
  }, [propDisplay3]);

  const name4Style: CSSProperties = useMemo(() => {
    return {
      display: propDisplay4,
    };
  }, [propDisplay4]);

  const name5Style: CSSProperties = useMemo(() => {
    return {
      display: propDisplay5,
    };
  }, [propDisplay5]);

  return (
    <div className="text-value-label">
      <div className="frame-column-container">
        <div className="type5" />
        <img className="icon1" alt="" src="/icon@2x.png" />
        <input className="name16" placeholder="Dashboard" type="text" />
      </div>
      <button className="frame-column-container1">
        <div className="type6" />
        <img
          className="general-01-icons-02-common"
          alt=""
          src="/00-general--01-icons--02-common--32-list@2x.png"
        />
        <div className="name17">Orders</div>
      </button>
      <div className="focus-input-frame">
        <div className="tip-icon-node">
          <div className="type7" />
          <img
            className="general-01-icons-05-financ"
            alt=""
            src="/00-general--01-icons--05-finance--08-tag@2x.png"
          />
          <div className="name18" style={nameStyle}>
            Products
          </div>
        </div>
        <div className="tip-icon-node1">
          <div className="type8" />
          <img
            className="general-01-icons-03-files"
            alt=""
            src="/00-general--01-icons--03-files--01-folder@2x.png"
          />
          <div className="name19" style={name1Style}>
            Categories
          </div>
        </div>
        <div className="tip-icon-node2">
          <div className="type9" />
          <img
            className="general-01-icons-02-common1"
            alt=""
            src="/00-general--01-icons--02-common--03-users@2x.png"
          />
          <div className="name20" style={name2Style}>
            Customers
          </div>
        </div>
      </div>
      <div className="frame-column-container2">
        <div className="type10" />
        <img
          className="general-01-icons-02-common2"
          alt=""
          src="/00-general--01-icons--02-common--09-statistics@2x.png"
        />
        <div className="name21" style={name3Style}>
          Reports
        </div>
      </div>
      <div className="frame-column-container3">
        <div className="type11" />
        <img
          className="general-01-icons-02-common3"
          alt=""
          src="/00-general--01-icons--02-common--11-star@2x.png"
        />
        <div className="name22" style={name4Style}>
          Coupons
        </div>
      </div>
      <div className="frame-column-container4">
        <div className="type12" />
        <img className="general-01-icons-04-commun" alt="" src="/chat@2x.png" />
        <div className="name23" style={name5Style}>
          Inbox
        </div>
      </div>
    </div>
  );
};

export default TextValueLabel;
