import { FunctionComponent, useState } from "react";
import Navigation08TopNavigation from "../components/Navigation08TopNavigation";
import Navigation1 from "../components/Navigation1";
import "./ExampleOrders.css";

const ExampleOrders: FunctionComponent = () => {
  const [checkbox1Checked, setCheckbox1Checked] = useState(true);
  const [checkbox2Checked, setCheckbox2Checked] = useState(true);
  const [checkbox3Checked, setCheckbox3Checked] = useState(true);
  const [checkbox4Checked, setCheckbox4Checked] = useState(true);
  const [checkbox5Checked, setCheckbox5Checked] = useState(true);
  return (
    <div className="example-orders">
      <Navigation08TopNavigation />
      <main className="icon-chevron-right">
        <Navigation1 />
        <section className="text-entr-box-node">
          <div className="frame-parent">
            <div className="orders-parent">
              <h2 className="orders">Orders</h2>
              <div className="button01-regular-button02-me-parent">
                <div className="button01-regular-button02-me">
                  <div className="focus-parent">
                    <div className="focus" />
                    <div className="type" />
                  </div>
                  <div className="text">
                    <div className="text-type-wrapper">
                      <div className="text-type">Export</div>
                    </div>
                  </div>
                </div>
                <button className="button02-icon-button02-mediu">
                  <div className="focus1" />
                  <div className="type1" />
                  <div className="text1" />
                  <div className="general-01-icons-01-action">
                    <div className="bg" />
                    <img className="color-icon" alt="" src="/color-1.svg" />
                  </div>
                  <div className="text-type1">Add Order</div>
                </button>
              </div>
            </div>
            <div className="orders1">
              <div className="bg1" />
              <div className="rectangle-button-regular">
                <div className="frame-dropdown-arrow">
                  <div className="dropdown01-regular-dropdown0">
                    <div className="focus2" />
                    <div className="field-type" />
                    <div className="arrow">
                      <div className="bg2" />
                      <img className="color-icon1" alt="" src="/color.svg" />
                    </div>
                    <div className="frame-input-search">
                      <div className="text-type2">
                        <div className="input-text">Filter</div>
                      </div>
                    </div>
                    <div className="title">
                      <div className="title-text">Title</div>
                    </div>
                  </div>
                  <div className="input06-search-input02-mediu">
                    <div className="focus3" />
                    <div className="field-type1" />
                    <input
                      className="frame-column-one"
                      placeholder="Search..."
                      type="text"
                    />
                    <img
                      className="icon"
                      alt=""
                      src="/00-general--01-icons--02-common--01-settings@2x.png"
                    />
                    <div className="title1">
                      <div className="title-text1">Title</div>
                    </div>
                  </div>
                </div>
                <div className="line-rectangle">
                  <div className="frame-pagination">
                    <img
                      className="button03-icon-only02-medium"
                      loading="eager"
                      alt=""
                      src="/01-button03-icon-only02-medium03-white@2x.png"
                    />
                    <img
                      className="button03-icon-only02-medium1"
                      alt=""
                      src="/01-button03-icon-only02-medium03-white-1@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="checkbox-container">
                <div className="header">
                  <div className="bg3" />
                  <div className="headerrowcheckboxes">
                    <div className="checkboxname-parent">
                      <div className="checkboxname">
                        <input className="checkbox" type="checkbox" />
                        <div className="name">Order</div>
                      </div>
                      <div className="columnonecolumntwo">
                        <div className="column-one">Date</div>
                      </div>
                      <div className="columnonecolumntwo1">
                        <div className="column-two">Customer</div>
                      </div>
                      <div className="otherbadgegreenone">
                        <div className="column-two1">Payment status</div>
                        <div className="column-two2">Order Status</div>
                      </div>
                      <div className="column-two3">Total</div>
                    </div>
                  </div>
                  <div className="line" />
                </div>
                <div className="row">
                  <div className="bg4" />
                  <div className="line1" />
                  <div className="checkboxselector">
                    <input
                      className="checkbox1"
                      checked={checkbox1Checked}
                      type="checkbox"
                      onChange={(event) =>
                        setCheckbox1Checked(event.target.checked)
                      }
                    />
                    <div className="name1">#12512B</div>
                  </div>
                  <div className="other-badgegreen-parent">
                    <div className="other-badgegreen">May 5, 4:20 PM</div>
                    <div className="badge-text-frame">Tom Anderson</div>
                    <div className="other03-badge01-light02-sma">
                      <div className="rectangle" />
                      <div className="badge">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma1">
                    <div className="badge-text-frame1" />
                    <div className="badge1">Ready</div>
                  </div>
                  <div className="text-frames-column">$49.90</div>
                </div>
                <div className="row1">
                  <div className="bg5" />
                  <div className="line2" />
                  <div className="checkbox-parent">
                    <input
                      className="checkbox2"
                      checked={checkbox2Checked}
                      type="checkbox"
                      onChange={(event) =>
                        setCheckbox2Checked(event.target.checked)
                      }
                    />
                    <div className="name2">#12523C</div>
                  </div>
                  <div className="text-parent">
                    <div className="text2">May 5, 4:15 PM</div>
                    <div className="text3">Jayden Walker</div>
                    <div className="other03-badge01-light02-sma2">
                      <div className="rectangle1" />
                      <div className="badge2">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma3">
                    <div className="rectangle2" />
                    <div className="badge3">Ready</div>
                  </div>
                  <div className="text4">$34.36</div>
                </div>
                <div className="row2">
                  <div className="bg6" />
                  <div className="line3" />
                  <div className="checkbox-group">
                    <input
                      className="checkbox3"
                      checked={checkbox3Checked}
                      type="checkbox"
                      onChange={(event) =>
                        setCheckbox3Checked(event.target.checked)
                      }
                    />
                    <div className="name3">#51232A</div>
                  </div>
                  <div className="text5">May 5, 4:15 PM</div>
                  <div className="text6">Inez Kim</div>
                  <div className="other03-badge01-light02-sma-wrapper">
                    <div className="other03-badge01-light02-sma4">
                      <div className="rectangle3" />
                      <div className="badge4">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-container">
                    <div className="other03-badge01-light02-sma5">
                      <div className="rectangle4" />
                      <div className="badge5">Ready</div>
                    </div>
                  </div>
                  <div className="text7">$5.51</div>
                </div>
                <div className="row3">
                  <div className="bg7" />
                  <div className="line4" />
                  <div className="frame-div">
                    <input
                      className="checkbox4"
                      checked={checkbox4Checked}
                      type="checkbox"
                      onChange={(event) =>
                        setCheckbox4Checked(event.target.checked)
                      }
                    />
                    <div className="name4">#23534D</div>
                  </div>
                  <div className="text8">May 5, 4:12 PM</div>
                  <div className="text-group">
                    <div className="text9">Francisco Henry</div>
                    <div className="other03-badge01-light02-sma6">
                      <div className="rectangle5" />
                      <div className="badge6">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-frame">
                    <div className="other03-badge01-light02-sma7">
                      <div className="rectangle6" />
                      <div className="badge7">Shipped</div>
                    </div>
                  </div>
                  <div className="text10">$29.74</div>
                </div>
                <div className="row4">
                  <div className="bg8" />
                  <div className="line5" />
                  <div className="checkbox-parent1">
                    <input
                      className="checkbox5"
                      checked={checkbox5Checked}
                      type="checkbox"
                      onChange={(event) =>
                        setCheckbox5Checked(event.target.checked)
                      }
                    />
                    <div className="name5">#51323C</div>
                  </div>
                  <div className="text-container">
                    <div className="text11">May 5, 4:12 PM</div>
                    <div className="text12">Violet Phillips</div>
                  </div>
                  <div className="other03-badge01-light02-sma-wrapper1">
                    <div className="other03-badge01-light02-sma8">
                      <div className="rectangle7" />
                      <div className="badge8">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-parent">
                    <div className="other03-badge01-light02-sma9">
                      <div className="rectangle8" />
                      <div className="badge9">Shipped</div>
                    </div>
                    <div className="text13">$23.06</div>
                  </div>
                </div>
                <div className="row5">
                  <div className="bg9" />
                  <div className="line6" />
                  <div className="checkbox-parent2">
                    <input className="checkbox6" type="checkbox" />
                    <div className="name6">#35622A</div>
                  </div>
                  <div className="text-parent1">
                    <div className="text14">May 5, 4:12 PM</div>
                    <div className="text15">Rosetta Becker</div>
                    <div className="other03-badge01-light02-sma10">
                      <div className="rectangle9" />
                      <div className="badge10">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma11">
                    <div className="rectangle10" />
                    <div className="badge11">Shipped</div>
                  </div>
                  <div className="text16">$87.44</div>
                </div>
                <div className="row6">
                  <div className="bg10" />
                  <div className="line7" />
                  <div className="checkbox-parent3">
                    <input className="checkbox7" type="checkbox" />
                    <div className="name7">#34232D</div>
                  </div>
                  <div className="text17">May 5, 4:10 PM</div>
                  <div className="text18">Dean Love</div>
                  <div className="other03-badge01-light02-sma-wrapper2">
                    <div className="other03-badge01-light02-sma12">
                      <div className="rectangle11" />
                      <div className="badge12">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-wrapper3">
                    <div className="other03-badge01-light02-sma13">
                      <div className="rectangle12" />
                      <div className="badge13">Ready</div>
                    </div>
                  </div>
                  <div className="text19">$44.55</div>
                </div>
                <div className="row7">
                  <div className="bg11" />
                  <div className="line8" />
                  <div className="checkbox-parent4">
                    <input className="checkbox8" type="checkbox" />
                    <div className="name8">#56212D</div>
                  </div>
                  <div className="text-parent2">
                    <div className="text20">May 5, 4:08 PM</div>
                    <div className="text21">Nettie Tyler</div>
                  </div>
                  <div className="other03-badge01-light02-sma-wrapper4">
                    <div className="other03-badge01-light02-sma14">
                      <div className="rectangle13" />
                      <div className="badge14">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-wrapper5">
                    <div className="other03-badge01-light02-sma15">
                      <div className="rectangle14" />
                      <div className="badge15">Ready</div>
                    </div>
                  </div>
                  <div className="text22">$36.79</div>
                </div>
                <div className="row8">
                  <div className="bg12" />
                  <div className="line9" />
                  <div className="checkbox-parent5">
                    <input className="checkbox9" type="checkbox" />
                    <div className="name9">#76543E</div>
                  </div>
                  <div className="text-parent3">
                    <div className="text23">May 5, 4:08 PM</div>
                    <div className="text24">Lora Weaver</div>
                  </div>
                  <div className="other03-badge01-light02-sma-wrapper6">
                    <div className="other03-badge01-light02-sma16">
                      <div className="rectangle15" />
                      <div className="badge16">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-group">
                    <div className="other03-badge01-light02-sma17">
                      <div className="rectangle16" />
                      <div className="badge17">Shipped</div>
                    </div>
                    <div className="text25">$28.78</div>
                  </div>
                </div>
                <div className="row9">
                  <div className="bg13" />
                  <div className="line10" />
                  <div className="checkbox-parent6">
                    <input className="checkbox10" type="checkbox" />
                    <div className="name10">#12512B</div>
                  </div>
                  <div className="text26">May 5, 4:05 PM</div>
                  <div className="text-parent4">
                    <div className="text27">Vincent Cannon</div>
                    <div className="other03-badge01-light02-sma18">
                      <div className="rectangle17" />
                      <div className="badge18">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-parent1">
                    <div className="other03-badge01-light02-sma19">
                      <div className="rectangle18" />
                      <div className="badge19">Shipped</div>
                    </div>
                    <div className="text28">$96.46</div>
                  </div>
                </div>
                <div className="row10">
                  <div className="bg14" />
                  <div className="line11" />
                  <div className="checkbox-parent7">
                    <input className="checkbox11" type="checkbox" />
                    <div className="name11">#12523C</div>
                  </div>
                  <div className="text-parent5">
                    <div className="text29">May 5, 4:05 PM</div>
                    <div className="text30">Nettie Palmer</div>
                    <div className="other03-badge01-light02-sma20">
                      <div className="rectangle19" />
                      <div className="badge20">Paid</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-parent2">
                    <div className="other03-badge01-light02-sma21">
                      <div className="rectangle20" />
                      <div className="badge21">Received</div>
                    </div>
                    <div className="text31">$25.53</div>
                  </div>
                </div>
                <div className="row11">
                  <div className="bg15" />
                  <div className="line12" />
                  <div className="checkbox-parent8">
                    <input className="checkbox12" type="checkbox" />
                    <div className="name12">#23534D</div>
                  </div>
                  <div className="text32">May 5, 4:04 PM</div>
                  <div className="text33">Miguel Harris</div>
                  <div className="other03-badge01-light02-sma-wrapper7">
                    <div className="other03-badge01-light02-sma22">
                      <div className="rectangle21" />
                      <div className="badge22">Pending</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-wrapper8">
                    <div className="other03-badge01-light02-sma23">
                      <div className="rectangle22" />
                      <div className="badge23">Ready</div>
                    </div>
                  </div>
                  <div className="text34">$50.54</div>
                </div>
                <div className="row12">
                  <div className="bg16" />
                  <div className="line13" />
                  <div className="checkbox-parent9">
                    <input className="checkbox13" type="checkbox" />
                    <div className="name13">#12523C</div>
                  </div>
                  <div className="text35">May 5, 4:04 PM</div>
                  <div className="text-parent6">
                    <div className="text36">Angel Conner</div>
                    <div className="other03-badge01-light02-sma24">
                      <div className="rectangle23" />
                      <div className="badge24">Pending</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-wrapper9">
                    <div className="other03-badge01-light02-sma25">
                      <div className="rectangle24" />
                      <div className="badge25">Ready</div>
                    </div>
                  </div>
                  <div className="text37">$63.47</div>
                </div>
                <div className="row13">
                  <div className="bg17" />
                  <div className="line14" />
                  <div className="checkbox-parent10">
                    <input className="checkbox14" type="checkbox" />
                    <div className="name14">#51232A</div>
                  </div>
                  <div className="text38">May 5, 4:03 PM</div>
                  <div className="text-parent7">
                    <div className="text39">Rosalie Singleton</div>
                    <div className="other03-badge01-light02-sma26">
                      <div className="rectangle25" />
                      <div className="badge26">Pending</div>
                    </div>
                  </div>
                  <div className="other03-badge01-light02-sma-parent3">
                    <div className="other03-badge01-light02-sma27">
                      <div className="rectangle26" />
                      <div className="badge27">Received</div>
                    </div>
                    <div className="text40">$91.63</div>
                  </div>
                </div>
              </div>
              <div className="pagination-parent">
                <div className="pagination">
                  <div className="arrow1">
                    <div className="bg18" />
                    <div className="icons-arrow-left">
                      <div className="bg19" />
                      <img className="color-icon2" alt="" src="/color-3.svg" />
                    </div>
                  </div>
                  <div className="number-parent">
                    <div className="number">
                      <div className="bg20" />
                      <div className="number1">1</div>
                    </div>
                    <div className="number2">
                      <div className="bg21" />
                      <div className="number3">2</div>
                    </div>
                    <div className="number4">
                      <div className="bg22" />
                      <div className="number5">3</div>
                    </div>
                    <div className="number6">
                      <div className="bg23" />
                      <div className="number7">4</div>
                    </div>
                    <div className="number8">
                      <div className="bg24" />
                      <div className="number9">5</div>
                    </div>
                    <div className="number10">
                      <div className="bg25" />
                      <div className="number11">6</div>
                    </div>
                    <div className="number12">
                      <div className="bg26" />
                      <div className="number13">...</div>
                    </div>
                    <div className="number14">
                      <div className="bg27" />
                      <div className="number15">24</div>
                    </div>
                  </div>
                  <img className="arrow-icon" alt="" src="/arrow-5@2x.png" />
                </div>
                <div className="results">274 Results</div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default ExampleOrders;
